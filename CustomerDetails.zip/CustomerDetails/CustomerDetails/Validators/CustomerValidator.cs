﻿using CustomerDetails.DTOs;

namespace CustomerDetails.Validators
{
    public static class CustomerValidator
    {
        public static bool IsValid(CustomerDTO customer)
        {
            return !string.IsNullOrWhiteSpace(customer.FullName)
                && customer.Email.Contains("@")
                && customer.Salary >= 0;
        }
    }
}
