﻿namespace CustomerDetails.Models
{
    public class Employement
    {
        public string CompanyName { get; set; }
        public string Designation { get; set; }
        public decimal Salary { get; set; }
    }
}
