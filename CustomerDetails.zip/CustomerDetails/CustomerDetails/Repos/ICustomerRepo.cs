﻿using CustomerDetails.Models;

namespace CustomerDetails.Repos
{
    public interface ICustomerRepo
    {
        Task<List<Customer>> GetAll();
        Task<Customer> Get(int id);
        Task Add(Customer customer);
        Task Update(int id, Customer customer);
        Task Delete(int id);
    }
}
