﻿using CustomerDetails.Data;
using CustomerDetails.Models;
using Microsoft.Data.SqlClient;
using static CustomerDetails.Repos.CustomerRepo;

namespace CustomerDetails.Repos
{
    public class CustomerRepo
    {
        public class CustomerRepository: ICustomerRepo
        {
            private readonly IConfiguration _config;

            public CustomerRepository(IConfiguration config)
            {
                _config = config;
            }

            public async Task<List<Customer>> GetAll()
            {
                var customers = new List<Customer>();
                using var conn = DbConnectionFactory.GetOpenConnection(_config);
                using var cmd = new SqlCommand("Select *from Customers", conn);
                using var reader = await cmd.ExecuteReaderAsync();

                while (await reader.ReadAsync())
                {
                    customers.Add(new Customer
                    {
                        Id = (int)reader["Id"],
                        FullName = reader["FullName"].ToString(),
                        Email = reader["Email"].ToString(),
                        Phone = reader["Phone"].ToString(),
                        Employement = new Employement
                        {
                            CompanyName = reader["CompanyName"].ToString(),
                            Designation = reader["Designation"].ToString(),
                            Salary = (decimal)reader["Salary"]
                        }
                    });
                }
                return customers;
            }

            public async Task<Customer> Get(int id)
            {
                using var conn = DbConnectionFactory.GetOpenConnection(_config);
                using var cmd = new SqlCommand("Select *from Customers where Id = @id", conn);
                cmd.Parameters.AddWithValue("@id", id);

                using var reader = await cmd.ExecuteReaderAsync();
                if (await reader.ReadAsync())
                {
                    return new Customer
                    {
                        Id = (int)reader["Id"],
                        FullName = reader["FullName"].ToString(),
                        Email = reader["Email"].ToString(),
                        Phone = reader["Phone"].ToString(),
                        Employement = new Employement
                        {
                            CompanyName = reader["CompanyName"].ToString(),
                            Designation = reader["Designation"].ToString(),
                            Salary = (decimal)reader["Salary"]
                        }
                    };
                }
                return null;
            }

            public async Task Add(Customer customer)
            {
                using var conn = DbConnectionFactory.GetOpenConnection(_config);
                using var cmd = new SqlCommand(@"
                Insert into Customers (FullName, Email, Phone, CompanyName, Designation, Salary)
                values (@FullName, @Email, @Phone, @CompanyName, @Designation, @Salary)", conn);

                cmd.Parameters.AddWithValue("@FullName", customer.FullName);
                cmd.Parameters.AddWithValue("@Email", customer.Email);
                cmd.Parameters.AddWithValue("@Phone", customer.Phone);
                cmd.Parameters.AddWithValue("@CompanyName", customer.Employement.CompanyName);
                cmd.Parameters.AddWithValue("@Designation", customer.Employement.Designation);
                cmd.Parameters.AddWithValue("@Salary", customer.Employement.Salary);

                await cmd.ExecuteNonQueryAsync();
            }

            public async Task Update(int id, Customer customer)
            {
                using var conn = DbConnectionFactory.GetOpenConnection(_config);
                using var cmd = new SqlCommand(@"
                Update Customers SET
                    FullName = @FullName,
                    Email = @Email,
                    Phone = @Phone,
                    CompanyName = @CompanyName,
                    Designation = @Designation,
                    Salary = @Salary
                WHERE Id = @Id", conn);

                cmd.Parameters.AddWithValue("@Id", id);
                cmd.Parameters.AddWithValue("@FullName", customer.FullName);
                cmd.Parameters.AddWithValue("@Email", customer.Email);
                cmd.Parameters.AddWithValue("@Phone", customer.Phone);
                cmd.Parameters.AddWithValue("@CompanyName", customer.Employement.CompanyName);
                cmd.Parameters.AddWithValue("@Designation", customer.Employement.Designation);
                cmd.Parameters.AddWithValue("@Salary", customer.Employement.Salary);

                await cmd.ExecuteNonQueryAsync();
            }

            public async Task Delete(int id)
            {
                using var conn = DbConnectionFactory.GetOpenConnection(_config);
                using var cmd = new SqlCommand("Delete from Customers WHERE Id = @Id", conn);
                cmd.Parameters.AddWithValue("@Id", id);
                await cmd.ExecuteNonQueryAsync();
            }
        }
    }
}
