﻿using Microsoft.Data.SqlClient;

namespace CustomerDetails.Data
{
    public class DbConnection
    {
    }

    public static class DbConnectionFactory
    {
        public static SqlConnection GetOpenConnection(IConfiguration config)
        {
            var conn = new SqlConnection(config.GetConnectionString("DefaultConnection"));
            conn.Open();
            return conn;
        }
    }
}
