﻿using CustomerDetails.DTOs;
using CustomerDetails.Services;
using CustomerDetails.Validators;
using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/[controller]")]
public class CustomerController : ControllerBase
{
    private readonly ICustomerService _service;

    public CustomerController(ICustomerService service)
    {
        _service = service;
    }

    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        return Ok(await _service.GetAll());
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> Get(int id)
    {
        return Ok(await _service.Get(id));
    }

    [HttpPost]
    public async Task<IActionResult> Create(CustomerDTO dto)
    {
        if (!CustomerValidator.IsValid(dto)) return BadRequest("Invalid Input Dataa");
        await _service.Add(dto);
        var updatedList = await _service.GetAll();
        return Ok(updatedList);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> Update(int id, CustomerDTO dto)
    {
        if (!CustomerValidator.IsValid(dto)) return BadRequest("Invalid Data");
        await _service.Update(id, dto);
        var updatedList = await _service.GetAll();
        return Ok(updatedList);
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        await _service.Delete(id);
        var updatedList = await _service.GetAll();
        return Ok(updatedList);
    }
}
