﻿using CustomerDetails.DTOs;
using CustomerDetails.Models;

namespace CustomerDetails.Services
{
    public interface ICustomerService
    {
        Task<List<Customer>> GetAll();
        Task<Customer> Get(int id);
        Task Add(CustomerDTO dto);
        Task Update(int id, CustomerDTO dto);
        Task Delete(int id);
    }
}
