﻿using CustomerDetails.Repos;
using CustomerDetails.DTOs;
using CustomerDetails.Models;

namespace CustomerDetails.Services
{
    public class CustomerService : ICustomerService
    {
        private readonly ICustomerRepo _repo;

        public CustomerService(ICustomerRepo repo)
        {
            _repo = repo;
        }

        public async Task<List<Customer>> GetAll()
        {
            return await _repo.GetAll();
        }

        public async Task<Customer> Get(int id)
        {
            return await _repo.Get(id);
        }

        public async Task Add(CustomerDTO dto)
        {
            var customer = MapDtoToCustomer(dto);
            await _repo.Add(customer);
        }

        public async Task Update(int id, CustomerDTO dto)
        {
            var customer = MapDtoToCustomer(dto);
            customer.Id = id;
            await _repo.Update(id, customer);
        }

        public async Task Delete(int id)
        {
            await _repo.Delete(id);
        }

        private Customer MapDtoToCustomer(CustomerDTO dto)
        {
            return new Customer
            {
                FullName = dto.FullName,
                Email = dto.Email,
                Phone = dto.Phone,
                Employement = new Employement
                {
                    CompanyName = dto.CompanyName,
                    Designation = dto.Designation,
                    Salary = dto.Salary
                }
            };
        }
    }
}
