﻿namespace CustomerDetails.DTOs
{
    public class CustomerDTO
    {
        public string FullName { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }

        public string CompanyName { get; set; }
        public string Designation { get; set; }
        public decimal Salary { get; set; }
    }
}
